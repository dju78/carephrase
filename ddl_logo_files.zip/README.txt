# DDL logo files

Use `ddl-logo.png` for your CareTalk UK project.

Place it here:

C:\Users\Inspiron\OneDrive\Documents\workplace\caretalk-uk\public\ddl-logo.png

Then run:

```powershell
cd "C:\Users\Inspiron\OneDrive\Documents\workplace\caretalk-uk"
git add public/ddl-logo.png
git commit -m "Add DDL logo"
git push origin main
```

The SVG files are included for future use because they stay sharp at any size.
